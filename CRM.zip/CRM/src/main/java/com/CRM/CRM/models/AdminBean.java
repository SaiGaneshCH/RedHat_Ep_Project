package com.CRM.CRM.models;

import java.util.List;

import javax.ejb.*;
import javax.faces.bean.ManagedBean;

import com.CRM.CRM.services.AdminService;

@ManagedBean(name = "adBean",eager = true)
public class AdminBean 
{
 // private int adid;
private String adname;
  private String adpwd;
  
  
//  public int getAdid() {
//	return adid;
//}
//
//
//
//public void setAdid(int adid) {
//	this.adid = adid;
//}



public String getAdname() {
	return adname;
}



public void setAdname(String adname) {
	this.adname = adname;
}



public String getAdpwd() {
	return adpwd;
}



public void setAdpwd(String adpwd) {
	this.adpwd = adpwd;
}


private String response;


  public String getResponse() {
	return response;
}



public void setResponse(String response) {
	this.response = response;
}

List<Admin> adlist;

public List<Admin> getAdlist() {
	return AdminService.viewadmins();
}

public void setAdlist(List<Admin> adlist) {
	this.adlist = adlist;
}


@EJB(lookup = "java:global/CRM/AdminServiceImpl!com.CRM.CRM.services.AdminService")
  AdminService AdminService;
  
  public void insertadmin()
  {
    try
    {
     Admin ad = new Admin();
     //ad.setAdid(adid);
     ad.setAdname(adname);
     ad.setAdpwd(adpwd);
     response = AdminService.insertadmin(ad);
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
  public void updateadmin()
  {
	  try
	  {
		  Admin ad = new Admin();
		  //ad.setAdid(adid);
		  ad.setAdname(adname);
		  ad.setAdpwd(adpwd);
		  response = AdminService.updateadmin(ad,adname);
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void deleteadmin()
  {
	  try
	  {
		  response = AdminService.deleteadmin(adname);
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void viewadmin()
  {
	  try
	  {
		 
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public String checkadmin()
  {
  	String page = null;

     try
     {
  		Admin ad = new Admin();
  		ad.setAdname(adname);
  		ad.setAdpwd(adpwd);
  	   	
  		Admin a = AdminService.checkadmin(ad);
  		
  		
  		
  		if(a!=null)
  	    {
  	  	  //System.out.println("Login Success");
  			//return "AdminPage.jsf";
  			page = "Welcome.jsf";
  	    }
  	    else
  	    {
  	  	  //System.out.println("Login Failed");
  	    	//return "AdminLogin.jsf";
  	    	response = "Please enter Valide Details!!";
  	    }

  		   
     }
     catch(Exception e)
     {
  	   System.out.println(e);
     }
     return page;
      
  }

}