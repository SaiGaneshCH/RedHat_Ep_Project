package com.CRM.CRM.models;

import java.util.List;

import javax.ejb.*;
import javax.faces.bean.ManagedBean;

import com.CRM.CRM.services.JobSeekerService;

@ManagedBean(name = "jsBean",eager = true)
public class JobSeekerBean 
{
private String jsid;
private String jsuname;
private String jspwd;
private String jsfname;
private String jsage;
private String jsgen;
private String jsdept;
private String jscerts;
private String jsskills;
private String jsyrsofexp;
  public String getJsid() {
	return jsid;
}



public void setJsid(String jsid) {
	this.jsid = jsid;
}



public String getJsuname() {
	return jsuname;
}



public void setJsuname(String jsuname) {
	this.jsuname = jsuname;
}



public String getJspwd() {
	return jspwd;
}



public void setJspwd(String jspwd) {
	this.jspwd = jspwd;
}



public String getJsfname() {
	return jsfname;
}



public void setJsfname(String jsfname) {
	this.jsfname = jsfname;
}



public String getJsage() {
	return jsage;
}



public void setJsage(String jsage) {
	this.jsage = jsage;
}



public String getJsgen() {
	return jsgen;
}



public void setJsgen(String jsgen) {
	this.jsgen = jsgen;
}



public String getJscerts() {
	return jscerts;
}



public void setJscerts(String jscerts) {
	this.jscerts = jscerts;
}



public String getJsskills() {
	return jsskills;
}



public void setJsskills(String jsskills) {
	this.jsskills = jsskills;
}



public String getJsyrsofexp() {
	return jsyrsofexp;
}



public void setJsyrsofexp(String jsyrsofexp) {
	this.jsyrsofexp = jsyrsofexp;
}




  public String getJsdept() {
	return jsdept;
}



public void setJsdept(String jsdept) {
	this.jsdept = jsdept;
} 
  

private String response;


  public String getResponse() {
	return response;
}



public void setResponse(String response) {
	this.response = response;
}

List<JobSeeker> jslist;

public List<JobSeeker> getJslist() {
	return JobSeekerService.viewjs();
}



public void setJslist(List<JobSeeker> jslist) {
	this.jslist = jslist;
}



@EJB(lookup = "java:global/CRM/JobSeekerServiceImpl!com.CRM.CRM.services.JobSeekerService")
JobSeekerService JobSeekerService;
  public void insertjs()
  {
    try
    {
     JobSeeker js = new JobSeeker();
     js.setJsuname(jsuname);
     js.setJspwd(jspwd);
     js.setJsfname(jsfname);
     js.setJsage(jsage);
     js.setJsdept(jsdept);
     js.setJsgen(jsgen);
     js.setJscerts(jscerts);
     js.setJsskills(jsskills);
     js.setJsyrsofexp(jsyrsofexp);
     response = JobSeekerService.insertjs(js);
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
  public void updatejs()
  {
	  try
	  {
		  JobSeeker js = new JobSeeker();
		     //js.setJsuname(jsuname);
		     js.setJspwd(jspwd);
		     js.setJsfname(jsfname);
		     js.setJsage(jsage);
		     js.setJsdept(jsdept);
		     js.setJsgen(jsgen);
		     js.setJscerts(jscerts);
		     js.setJsskills(jsskills);
		     js.setJsyrsofexp(jsyrsofexp);
		     response = JobSeekerService.updatejs(js, jsuname);  
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void deletejs()
  {
	  try
	  {
		  response = JobSeekerService.deletejs(jsuname);
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void viewjs()
  {
	  try
	  {
		 
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public String checkjseeker()
  {
	  String page = null;

	     try
	     {
	  		JobSeeker js = new JobSeeker();
	  		js.setJsuname(jsuname);
	  		js.setJspwd(jspwd);
	  		
	  	   	
	  		JobSeeker j = JobSeekerService.checkjseeker(js);
	  		
	  		
	  		
	  		if(j!=null)
	  	    {
	  	  	  //System.out.println("Login Success");
	  			
	  			page = "Welcome.jsf";
	  	    }
	  	    else
	  	    {
	  	  	  //System.out.println("Login Failed");
	  	    	response = "Please enter Valide Details!!";
	  	    }

	  		   
	     }
	     catch(Exception e)
	     {
	  	   System.out.println(e);
	     }
	     return page;
  }
}