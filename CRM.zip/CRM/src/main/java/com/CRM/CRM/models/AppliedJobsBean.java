package com.CRM.CRM.models;

import java.util.List;

import javax.ejb.*;
import javax.faces.bean.ManagedBean;

import com.CRM.CRM.services.JobOffersService;
import com.CRM.CRM.services.AppliedJobsService;

@ManagedBean(name = "ajBean",eager = true)
public class AppliedJobsBean 
{
	  private String cname;
	  public String getCname() {
		return cname;
	}



	public void setCname(String cname) {
		this.cname = cname;
	}



	public String getJrole() {
		return jrole;
	}



	public void setJrole(String jrole) {
		this.jrole = jrole;
	}



	public int getPack() {
		return pack;
	}



	public void setPack(int pack) {
		this.pack = pack;
	}



	public int getMinCGPA() {
		return minCGPA;
	}



	public void setMinCGPA(int minCGPA) {
		this.minCGPA = minCGPA;
	}



	public String getApstat() {
		return apstat;
	}



	public void setApstat(String apstat) {
		this.apstat = apstat;
	}



	public List<JobOffers> getJolist() {
		return jolist;
	}



	public void setJolist(List<JobOffers> jolist) {
		this.jolist = jolist;
	}

	private String jrole;
	  private int pack;
	  private int minCGPA;
	  private String apstat;





private String response;


  public String getResponse() {
	return response;
}



public void setResponse(String response) {
	this.response = response;
}

List<JobOffers> jolist;



@EJB(lookup = "java:global/CRM/JobOffersServiceImpl!com.CRM.CRM.services.JobOffersService")
  JobOffersService JobOffersService;
  
  public void insertjob()
  {
    try
    {
    	JobOffers jo = new JobOffers();
    	jo.setCname(cname);
    	jo.setJrole(jrole);
    	jo.setApstat(apstat);
    	jo.setMinCGPA(minCGPA);
    	jo.setPack(pack);
    
     response = JobOffersService.insertjob(jo);
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
  public void updatejob()
  {
	  try
	  {
		  JobOffers jo = new JobOffers();
	    	jo.setCname(cname);
	    	jo.setJrole(jrole);
	    	jo.setApstat(apstat);
	    	jo.setMinCGPA(minCGPA);
	    	jo.setPack(pack);		 
		  response = JobOffersService.updatejob(jo,jrole);
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void deletejob()
  {
	  try
	  {
		  response = JobOffersService.deletejob(jrole);
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void viewjob()
  {
	  try
	  {
		 
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
  public void checkapstatus()
  {
	  try 
	  {
		

	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
}