package com.CRM.CRM.services;

import java.util.List;

import javax.ejb.Remote;

import com.CRM.CRM.models.JobSeeker;

@Remote
public interface JobSeekerService 
{
   public String insertjs(JobSeeker js);
   public String updatejs(JobSeeker js, String jsuname);
   public String deletejs(String jsuname);
   public JobSeeker checkjseeker(JobSeeker js);
   public List<JobSeeker> viewjs();
}