package com.CRM.CRM.models;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="AdminTable")
public class Admin implements Serializable
{
  private static final long serialVersionUID = 1L;
  @Id
//  @Column(name="AdminID")
//  private int adid;
  @Column(name="AdminName")
  private String adname;
  @Column(name="AdminPassword")
  private String adpwd;
  
  
//public int getAdid() {
//	return adid;
//}
//public void setAdid(int adid) {
//	this.adid = adid;
//}
public String getAdname() {
	return adname;
}
public void setAdname(String adname) {
	this.adname = adname;
}
public String getAdpwd() {
	return adpwd;
}
public void setAdpwd(String adpwd) {
	this.adpwd = adpwd;
}

  
  
}