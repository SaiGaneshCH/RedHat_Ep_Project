package com.CRM.CRM.services;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.CRM.CRM.models.JobOffers;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class JobOffersServiceImpl implements JobOffersService
{

  @Override
  public String insertjob(JobOffers jo) 
  {
    
      EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
      EntityManager entityManager = entityManagerFactory.createEntityManager();
            
      entityManager.getTransaction().begin();
      entityManager.persist(jo);
      entityManager.getTransaction().commit();
      
      entityManager.close();
      entityManagerFactory.close();
      
      return "Added New Job Successfully" ;
  }
  @Override
  public String updatejob(JobOffers jo,String jrole) 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();	  

	    entityManager.getTransaction().begin();
	    JobOffers j=entityManager.find(JobOffers.class,jrole);
	    j.setCname(jo.getCname());
	    j.setJrole(jo.getJrole());
	    j.setPack(jo.getPack());
	    j.setMinCGPA(jo.getMinCGPA());
	    j.setApstat(jo.getApstat());
	    
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return "Object Updated Successfully" ;
  }
  @Override
  public String deletejob(String jrole) 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  
	  System.out.println("I am in Service Implementation");
	  
	  entityManager.getTransaction().begin();
	  JobOffers j = entityManager.find(JobOffers.class,jrole);
	    entityManager.remove(j);
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return "Object Deleted Successfully" ;
  }
  @Override
  public List<JobOffers> viewjobs() 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  
	  
	  entityManager.getTransaction().begin();
	    Query qry=entityManager.createQuery("select jo from JobOffers jo");
	    List<JobOffers> jolist = qry.getResultList();
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return jolist ;
  }
 
  @Override
  public String checkapstatus(JobOffers jo) 
  {
	return null;
    
  }
}