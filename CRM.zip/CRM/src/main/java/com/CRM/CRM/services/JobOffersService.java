package com.CRM.CRM.services;

import java.util.List;

import javax.ejb.Remote;

import com.CRM.CRM.models.JobOffers;

@Remote
public interface JobOffersService 
{
   public String insertjob(JobOffers jo);
   public String updatejob(JobOffers jo, String cname);
   public String deletejob(String jrole);
   public String checkapstatus(JobOffers jo);
   public List<JobOffers> viewjobs();
}