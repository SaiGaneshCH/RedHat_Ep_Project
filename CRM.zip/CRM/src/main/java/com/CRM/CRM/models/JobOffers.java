package com.CRM.CRM.models;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="JobOffers")
public class JobOffers implements Serializable
{
  private static final long serialVersionUID = 1L;
  @Id @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name="JobId")
  private int id;
  public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@Column(name="CompanyName")
  private String cname;
  public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getJrole() {
	return jrole;
}
public void setJrole(String jrole) {
	this.jrole = jrole;
}
public int getPack() {
	return pack;
}
public void setPack(int pack) {
	this.pack = pack;
}
public int getMinCGPA() {
	return minCGPA;
}
public void setMinCGPA(int minCGPA) {
	this.minCGPA = minCGPA;
}
public String getApstat() {
	return apstat;
}
public void setApstat(String apstat) {
	this.apstat = apstat;
}
@Column(name="JobRole")
  private String jrole;
  @Column(name="Package")
  private int pack;
  @Column(name="MinCGPA")
  private int minCGPA;
  @Column(name="AppliedStatus")
  private String apstat;


  
}