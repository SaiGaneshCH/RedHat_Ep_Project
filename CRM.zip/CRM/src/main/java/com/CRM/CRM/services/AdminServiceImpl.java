package com.CRM.CRM.services;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.CRM.CRM.models.Admin;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class AdminServiceImpl implements AdminService
{

  @Override
  public String insertadmin(Admin ad) 
  {
    
      EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
      EntityManager entityManager = entityManagerFactory.createEntityManager();
            
      entityManager.getTransaction().begin();
      entityManager.persist(ad);
      entityManager.getTransaction().commit();
      
      entityManager.close();
      entityManagerFactory.close();
      
      return "Registered Successfully" ;
  }
  @Override
  public String updateadmin(Admin ad,String adname) 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();	  

	    entityManager.getTransaction().begin();
	    Admin a=entityManager.find(Admin.class,adname);
	    //a.setAdid(ad.getAdid());
	    a.setAdname(ad.getAdname());
	    a.setAdpwd(ad.getAdpwd());
	    
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return "Object Updated Successfully" ;
  }
  @Override
  public String deleteadmin(String adname) 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  
	  System.out.println("I am in Service Implementation");
	  
	  entityManager.getTransaction().begin();
	    Admin a=entityManager.find(Admin.class,adname);
	    entityManager.remove(a);
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return "Object Deleted Successfully" ;
  }
  @Override
  public List<Admin> viewadmins() 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  
	  
	  entityManager.getTransaction().begin();
	    Query qry=entityManager.createQuery("select ad from Admin ad");
	    List<Admin> adlist = qry.getResultList();
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return adlist ;
  }
 
  @Override
  public Admin checkadmin(Admin ad) 
  {
	  System.out.println("I am in Check Admin Login Method");	
	    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
	    
	    
	    entityManager.getTransaction().begin();
	    Query qry=entityManager.createQuery("select ad from Admin ad where adname=? and  adpwd=?");
	    qry.setParameter(1, ad.getAdname());
	    qry.setParameter(2, ad.getAdpwd());
	    
	    Admin admin1 = null;
	    
	    if (qry.getResultList().size()==1) 
	    {
	    	admin1 = (Admin) qry.getSingleResult();
	    }
	    
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	    
	    return admin1;
//      EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
//      EntityManager entityManager = entityManagerFactory.createEntityManager();
//            
//      entityManager.getTransaction().begin();
//      Admin a=entityManager.find(Admin.class,ad);
//	  boolean a = entityManager.contains(ad);
//      entityManager.getTransaction().commit();
//      
//      entityManager.close();
//      entityManagerFactory.close();
//      if(a!=null) {
//      return "Logged in Successfully" ;
//  
//      }
//      else
//      {
//    	  return "Account Not Found!!";
//      }
  }
}