package com.CRM.CRM.services;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.CRM.CRM.models.Admin;
import com.CRM.CRM.models.JobSeeker;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class JobSeekerServiceImpl implements JobSeekerService
{

  @Override
  public String insertjs(JobSeeker js) 
  {
    
      EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
      EntityManager entityManager = entityManagerFactory.createEntityManager();
            
      entityManager.getTransaction().begin();
      entityManager.persist(js);
      entityManager.getTransaction().commit();
      
      entityManager.close();
      entityManagerFactory.close();
      
      return "Registered Successfully" ;
  }
  @Override
  public String updatejs(JobSeeker js,String jsuname) 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();	  

	    entityManager.getTransaction().begin();
	    JobSeeker j = entityManager.find(JobSeeker.class,jsuname);
	    //j.setJsuname(j.getJsuname());
	    j.setJspwd(j.getJspwd());
	    j.setJsfname(j.getJsfname());
	    j.setJsage(j.getJsage());
	    j.setJsdept(j.getJsdept());
	    j.setJsgen(j.getJsgen());
	    j.setJscerts(j.getJscerts());
	    j.setJsskills(j.getJsskills());
	    j.setJsyrsofexp(j.getJsyrsofexp());
	    
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return "Object Updated Successfully" ;
  }
  @Override
  public String deletejs(String jsuname) 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  
	  System.out.println("I am in Service Implementation");
	  
	  entityManager.getTransaction().begin();
	  JobSeeker j = entityManager.find(JobSeeker.class,jsuname);
	    entityManager.remove(j);
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return "Object Deleted Successfully" ;
  }
  @Override
  public List<JobSeeker> viewjs() 
  {
	  
	  EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  
	  
	  entityManager.getTransaction().begin();
	    Query qry=entityManager.createQuery("select js from JobSeeker js");
	    List<JobSeeker> jslist = qry.getResultList();
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	  
	  return jslist ;
  }
 
  @Override
  public JobSeeker checkjseeker(JobSeeker js) 
  {
	  System.out.println("I am in Check JobSeeker Login Method");	
	    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
	    
	    
	    entityManager.getTransaction().begin();
	    Query qry=entityManager.createQuery("select js from JobSeeker js where jsuname=? and  jspwd=?");
	    qry.setParameter(1, js.getJsuname());
	    qry.setParameter(2, js.getJspwd());
	    
	    JobSeeker jseeker = null;
	    
	    if (qry.getResultList().size()==1) 
	    {
	    	jseeker = (JobSeeker) qry.getSingleResult();
	    }
	    
	    entityManager.getTransaction().commit();
	    
	    entityManager.close();
	    entityManagerFactory.close();
	    
	    return jseeker;
//      EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CRM");
//      EntityManager entityManager = entityManagerFactory.createEntityManager();
//            
//      entityManager.getTransaction().begin();
//      JobSeeker j=entityManager.find(JobSeeker.class,js);
//	  boolean a = entityManager.contains(ad);
//      entityManager.getTransaction().commit();
//      
//      entityManager.close();
//      entityManagerFactory.close();
//      if(j!=null) {
//      return "Logged in Successfully" ;
//  
//      }
//      else
//      {
//    	  return "Account Not Found!!";
//      }
    }
}