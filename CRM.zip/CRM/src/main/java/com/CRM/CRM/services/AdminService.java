package com.CRM.CRM.services;

import java.util.List;

import javax.ejb.Remote;

import com.CRM.CRM.models.Admin;

@Remote
public interface AdminService 
{
   public String insertadmin(Admin ad);
   public String updateadmin(Admin ad, String adname);
   public String deleteadmin(String adname);
   public Admin checkadmin(Admin ad);
   public List<Admin> viewadmins();
}