package com.CRM.CRM.models;

import java.io.Serializable;

import javax.persistence.*;
//need to add CGPA
@Entity
@Table(name="JobSeeker")
public class JobSeeker implements Serializable
{
  private static final long serialVersionUID = 1L;
  @Id @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name="JSID")
  private int jsid;
  @Column(name="JSUName")
  private String jsuname;
  @Column(name="JSPassword")
  private String jspwd;
  @Column(name="JSFName")
  private String jsfname;
  @Column(name="JSAge")
  private String jsage;
  @Column(name="JSDept")
  private String jsdept;
  @Column(name="JSGender")
  private String jsgen;
  @Column(name="JSCertificates")
  private String jscerts;
  @Column(name="JSAddtionalSkills")
  private String jsskills;
  @Column(name="JSYearsOfExperience")
  private String jsyrsofexp;
  public String getJsdept() {
	return jsdept;
}
public void setJsdept(String jsdept) {
	this.jsdept = jsdept;
}
  
  
  public int getJsid() {
	return jsid;
}
public void setJsid(int jsid) {
	this.jsid = jsid;
}
public String getJsuname() {
	return jsuname;
}
public void setJsuname(String jsuname) {
	this.jsuname = jsuname;
}
public String getJspwd() {
	return jspwd;
}
public void setJspwd(String jspwd) {
	this.jspwd = jspwd;
}
public String getJsfname() {
	return jsfname;
}
public void setJsfname(String jsfname) {
	this.jsfname = jsfname;
}
public String getJsage() {
	return jsage;
}
public void setJsage(String jsage) {
	this.jsage = jsage;
}
public String getJsgen() {
	return jsgen;
}
public void setJsgen(String jsgen) {
	this.jsgen = jsgen;
}
public String getJscerts() {
	return jscerts;
}
public void setJscerts(String jscerts) {
	this.jscerts = jscerts;
}
public String getJsskills() {
	return jsskills;
}
public void setJsskills(String jsskills) {
	this.jsskills = jsskills;
}
public String getJsyrsofexp() {
	return jsyrsofexp;
}
public void setJsyrsofexp(String jsyrsofexp) {
	this.jsyrsofexp = jsyrsofexp;
}

  

  
  
}